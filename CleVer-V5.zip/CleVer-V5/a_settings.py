﻿# -*- coding: utf-8 -*-

#-------------------------------------------------------#
#				 CLEVER-BOt Settings File
#				 CLEVER © By KinG-SyRia
#-------------------------------------------------------#
#كونفاج البوت#
Setting = {
'JidBot': 'clever@service.com',	# حساب البوت
'PassBot': 'asd22',	# باسورد البوت
'ResBot': 'Bot',	# ريس البوت
'NickBot': u'-1',		# لقب البوت
'ShowBot': 'dnd',	# حالة البوت [dnd online away chat]
'StatusBot': 'http://service.com/ \nBOT CLEVER \nking-syria@service.com ',	# نص حالة البوت
'RoomBot': u'clever@conference.service.com',	# روم البوت
'JidIp': 'king-syria@service.com'}	# حساب صاحب التصريح 
AdminBot = u'king-syria@service.com',u''	# ادمن البوت 
#-------------------------------------------------------#
#اعدادت البوت#
#انظر الى ملف other.py#