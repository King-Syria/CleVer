﻿# -*- coding: utf-8 -*-

#-------------------------------------------------------#
#				 CLEVER-BOt Settings File
#				 CLEVER © By KinG-SyRia
#-------------------------------------------------------#
#كونفاج البوت#
Setting = {
'JidBot': 'clever@syriatalk.org',	# حساب البوت
'PassBot': 'asd22',	# باسورد البوت
'ResBot': 'Bot',	# ريس البوت
'NickBot': u'-1',		# لقب البوت
'ShowBot': 'dnd',	# حالة البوت [dnd online away chat]
'StatusBot': 'http://syriatalk.org/ \nBOT CLEVER \nking-syria@syriatalk.org ',	# نص حالة البوت
'RoomBot': u'clever@conference.syriatalk.org',	# روم البوت
'JidIp': 'king-syria@syriatalk.org'}	# حساب صاحب التصريح 
AdminBot = u'king-syria@syriatalk.org',u''	# ادمن البوت 
#-------------------------------------------------------#
#اعدادت البوت#
#انظر الى ملف other.py#